---
title: Arrow right square
layout: icon
categories:
  - Shape Arrows
tags:
  - arrow
  - square
---
