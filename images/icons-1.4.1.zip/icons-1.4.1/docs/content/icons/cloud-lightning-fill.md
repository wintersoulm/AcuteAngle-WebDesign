---
title: Cloud lightning fill
categories:
  - Weather
tags:
  - thunder
  - storm
---
